(({   imports: $h‍_imports,   liveVar: $h‍_live,   onceVar: $h‍_once,   importMeta: $h‍____meta,  }) => {   let TOCNotesPanel,registerTOCComponents,useState,useCallback,useRef,createElement,createRoot,jsx,Tooltip,pushLayoutAtom,deleteLayoutAtom,currentPageAtom,assertExists,RightSidebarIcon,IconButton,useSetAtom,useAtomValue;$h‍_imports([["@blocksuite/blocks", [["TOCNotesPanel", [$h‍_a => (TOCNotesPanel = $h‍_a)]],["registerTOCComponents", [$h‍_a => (registerTOCComponents = $h‍_a)]]]],["react", [["useState", [$h‍_a => (useState = $h‍_a)]],["useCallback", [$h‍_a => (useCallback = $h‍_a)]],["useRef", [$h‍_a => (useRef = $h‍_a)]],["createElement", [$h‍_a => (createElement = $h‍_a)]]]],["react-dom/client", [["createRoot", [$h‍_a => (createRoot = $h‍_a)]]]],["react/jsx-runtime", [["jsx", [$h‍_a => (jsx = $h‍_a)]]]],["@affine/component", [["Tooltip", [$h‍_a => (Tooltip = $h‍_a)]]]],["@affine/sdk/entry", [["pushLayoutAtom", [$h‍_a => (pushLayoutAtom = $h‍_a)]],["deleteLayoutAtom", [$h‍_a => (deleteLayoutAtom = $h‍_a)]],["currentPageAtom", [$h‍_a => (currentPageAtom = $h‍_a)]]]],["@blocksuite/global/utils", [["assertExists", [$h‍_a => (assertExists = $h‍_a)]]]],["@blocksuite/icons", [["RightSidebarIcon", [$h‍_a => (RightSidebarIcon = $h‍_a)]]]],["@toeverything/components/button", [["IconButton", [$h‍_a => (IconButton = $h‍_a)]]]],["jotai", [["useSetAtom", [$h‍_a => (useSetAtom = $h‍_a)]],["useAtomValue", [$h‍_a => (useAtomValue = $h‍_a)]]]]]);   










const Outline=  ()=>  {
  const tocPanelRef=  useRef(null);
  const currentPage=  useAtomValue(currentPageAtom);
  if( !tocPanelRef.current) {
    tocPanelRef.current=  new TOCNotesPanel();
   }
  if( currentPage!==  tocPanelRef.current?.page) {
    tocPanelRef.current.page=  currentPage;
   }
  return /* @__PURE__ */ jsx(
    "div",
    {
      className:  `outline-wrapper`,
      style: {
        height: "100%",
        borderLeft:  `1px solid var(--affine-border-color)`},

      ref: useCallback((container)=>  {
        if( container) {
          assertExists(tocPanelRef.current);
          container.appendChild(tocPanelRef.current);
         }
       },[])});


 };
const HeaderItem=  ({
  Provider})=>
      {
  const [open, setOpen]=  useState(false);
  const pushLayout=  useSetAtom(pushLayoutAtom);
  const deleteLayout=  useSetAtom(deleteLayoutAtom);
  const [container, setContainer]=  useState(null);
  return /* @__PURE__ */ jsx(
    Tooltip,
    {
      content:  `${open? "Collapse":  "Expand" } table of contents`,
      portalOptions: {
        container},

      children: /* @__PURE__ */ jsx(
        IconButton,
        {
          ref: setContainer,
          onClick: useCallback(()=>  {
            if( !open) {
              setOpen(true);
              pushLayout(
                "@affine/outline-plugin",
                (div)=>  {
                  const root=  createRoot(div);
                  div.style.height=  "100%";
                  root.render(
                    /* @__PURE__ */ jsx(Provider, { children: /* @__PURE__ */ jsx(Outline, {})}));

                  return ()=>  {
                    root.unmount();
                   };
                 },
                {
                  maxWidth: [void 0, 300]});


             }else {
              setOpen(false);
              deleteLayout("@affine/outline-plugin");
             }
           },[Provider, deleteLayout, open, pushLayout]),
          children: /* @__PURE__ */ jsx(RightSidebarIcon, {})})});




 };

const entry=  (context)=>  {
  console.log("register outline");
  context.register("headerItem", (div)=>  {
    registerTOCComponents((components)=>  {
      for( const compName in components) {
        if( window.customElements.get(compName))
          continue;
        window.customElements.define(
          compName,
          components[compName]);

       }
     });
    div.style.height=  "100%";
    const root=  createRoot(div);
    root.render(
      createElement(
        context.utils.PluginProvider,
        {},
        createElement(HeaderItem, {
          Provider: context.utils.PluginProvider})));



    return ()=>  {
      root.unmount();
     };
   });
  return ()=>  {
   };
 };$h‍_once.entry(entry);
})
//# sourceURL=index.js
