(({   imports: $h‍_imports,   liveVar: $h‍_live,   onceVar: $h‍_once,   importMeta: $h‍____meta,  }) => {   let useState,createContext,Component,isValidElement,createElement,useCallback,useEffect,Suspense,useRef,createRoot,jsx,jsxs,toast$1,Tooltip,assertExists,ArrowLeftSmallIcon,ArrowRightSmallIcon,ViewBarIcon,MinusIcon,PlusIcon,DownloadIcon,CopyIcon,DeleteIcon,IconButton,Button,atom,useAtom,useSWR;$h‍_imports([["react", [["useState", [$h‍_a => (useState = $h‍_a)]],["createContext", [$h‍_a => (createContext = $h‍_a)]],["Component", [$h‍_a => (Component = $h‍_a)]],["isValidElement", [$h‍_a => (isValidElement = $h‍_a)]],["createElement", [$h‍_a => (createElement = $h‍_a)]],["useCallback", [$h‍_a => (useCallback = $h‍_a)]],["useEffect", [$h‍_a => (useEffect = $h‍_a)]],["Suspense", [$h‍_a => (Suspense = $h‍_a)]],["useRef", [$h‍_a => (useRef = $h‍_a)]]]],["react-dom/client", [["createRoot", [$h‍_a => (createRoot = $h‍_a)]]]],["react/jsx-runtime", [["jsx", [$h‍_a => (jsx = $h‍_a)]],["jsxs", [$h‍_a => (jsxs = $h‍_a)]]]],["@affine/component", [["toast", [$h‍_a => (toast$1 = $h‍_a)]],["Tooltip", [$h‍_a => (Tooltip = $h‍_a)]]]],["@blocksuite/global/utils", [["assertExists", [$h‍_a => (assertExists = $h‍_a)]]]],["@blocksuite/icons", [["ArrowLeftSmallIcon", [$h‍_a => (ArrowLeftSmallIcon = $h‍_a)]],["ArrowRightSmallIcon", [$h‍_a => (ArrowRightSmallIcon = $h‍_a)]],["ViewBarIcon", [$h‍_a => (ViewBarIcon = $h‍_a)]],["MinusIcon", [$h‍_a => (MinusIcon = $h‍_a)]],["PlusIcon", [$h‍_a => (PlusIcon = $h‍_a)]],["DownloadIcon", [$h‍_a => (DownloadIcon = $h‍_a)]],["CopyIcon", [$h‍_a => (CopyIcon = $h‍_a)]],["DeleteIcon", [$h‍_a => (DeleteIcon = $h‍_a)]]]],["@toeverything/components/button", [["IconButton", [$h‍_a => (IconButton = $h‍_a)]],["Button", [$h‍_a => (Button = $h‍_a)]]]],["jotai", [["atom", [$h‍_a => (atom = $h‍_a)]],["useAtom", [$h‍_a => (useAtom = $h‍_a)]]]],["swr", [["default", [$h‍_a => (useSWR = $h‍_a)]]]]]);   









function r(e){var t,f,n="";if("string"==typeof e||"number"==typeof e)n+=e;else if("object"==typeof e)if(Array.isArray(e))for(t=0;t<e.length;t++)e[t]&&(f=r(e[t]))&&(n&&(n+=" "),n+=f);else for(t in e)e[t]&&(n&&(n+=" "),n+=t);return n;}function clsx(){for(var e,t,f=0,n="";f<arguments.length;)(e=arguments[f++])&&(t=r(e))&&(n&&(n+=" "),n+=t);return n;}

let t=(r)=>!1!==r&&null!=r,o=function(){let o=arguments.length>0&&void 0!==arguments[0]&&arguments[0],[e,n]=useState(!1);if(t(o))throw o;if(t(e))throw e;return n;};

const ErrorBoundaryContext=  createContext(null);

const initialState=  {
  didCatch: false,
  error: null};

class ErrorBoundary extends Component {
             constructor(props){
    super(props);
    this.resetErrorBoundary=  this.resetErrorBoundary.bind(this);
    this.state=  initialState;
   }
                                 static getDerivedStateFromError(error){
    return {
      didCatch: true,
      error};

   }
                    resetErrorBoundary(){
    const {
      error}=
        this.state;
    if( error!==  null) {
      var _this$props$onReset, _this$props;
      for( var _len=  arguments.length, args=  new Array(_len), _key=  0; _key<  _len; _key++) {
        args[_key]=  arguments[_key];
       }
      (_this$props$onReset=  (_this$props=  this.props).onReset)===  null||  _this$props$onReset===  void 0?  void 0:  _this$props$onReset.call(_this$props, {
        args,
        reason: "imperative-api"});

      this.setState(initialState);
     }
   }
                   componentDidCatch(error,info){
    var _this$props$onError, _this$props2;
    (_this$props$onError=  (_this$props2=  this.props).onError)===  null||  _this$props$onError===  void 0?  void 0:  _this$props$onError.call(_this$props2, error, info);
   }
                    componentDidUpdate(prevProps,prevState){
    const {
      didCatch}=
        this.state;
    const {
      resetKeys}=
        this.props;

    // There's an edge case where if the thing that triggered the error happens to *also* be in the resetKeys array,
    // we'd end up resetting the error boundary immediately.
    // This would likely trigger a second error to be thrown.
    // So we make sure that we don't check the resetKeys on the first call of cDU after the error is set.

    if( didCatch&&  prevState.error!==  null&&  hasArrayChanged(prevProps.resetKeys, resetKeys)) {
      var _this$props$onReset2, _this$props3;
      (_this$props$onReset2=  (_this$props3=  this.props).onReset)===  null||  _this$props$onReset2===  void 0?  void 0:  _this$props$onReset2.call(_this$props3, {
        next: resetKeys,
        prev: prevProps.resetKeys,
        reason: "keys"});

      this.setState(initialState);
     }
   }
        render(){
    const {
      children,
      fallbackRender,
      FallbackComponent,
      fallback}=
        this.props;
    const {
      didCatch,
      error}=
        this.state;
    let childToRender=  children;
    if( didCatch) {
      const props=  {
        error,
        resetErrorBoundary: this.resetErrorBoundary};

      if( isValidElement(fallback)) {
        childToRender=  fallback;
       }else if( typeof fallbackRender===  "function") {
        childToRender=  fallbackRender(props);
       }else if( FallbackComponent) {
        childToRender=  createElement(FallbackComponent, props);
       }else {
        throw error;
       }
     }
    return createElement(ErrorBoundaryContext.Provider, {
      value: {
        didCatch,
        error,
        resetErrorBoundary: this.resetErrorBoundary}},

       childToRender);
   }}

function hasArrayChanged() {
  let a=  arguments.length>  0&&  arguments[0]!==  undefined?  arguments[0]:  [];
  let b=  arguments.length>  1&&  arguments[1]!==  undefined?  arguments[1]:  [];
  return a.length!==  b.length||  a.some((item, index)=>  !Object.is(item, b[index]));
 }

const useZoomControls=  ({
  zoomRef,
  imageRef})=>
      {
  const [currentScale, setCurrentScale]=  useState(1);
  const [isZoomedBigger, setIsZoomedBigger]=  useState(false);
  const [isDragging, setIsDragging]=  useState(false);
  const [mouseX, setMouseX]=  useState(0);
  const [mouseY, setMouseY]=  useState(0);
  const [dragBeforeX, setDragBeforeX]=  useState(0);
  const [dragBeforeY, setDragBeforeY]=  useState(0);
  const [imagePos, setImagePos]=  useState({
    x: 0,
    y: 0});

  const handleDragStart=  useCallback(
    (event)=>  {
      event?.preventDefault();
      setIsDragging(true);
      const image=  imageRef.current;
      if( image&&  isZoomedBigger) {
        image.style.cursor=  "grab";
        const rect=  image.getBoundingClientRect();
        setDragBeforeX(rect.left);
        setDragBeforeY(rect.top);
        setMouseX(event.clientX);
        setMouseY(event.clientY);
       }
     },
    [imageRef, isZoomedBigger]);

  const handleDrag=  useCallback(
    (event)=>  {
      event?.preventDefault();
      const image=  imageRef.current;
      if( isDragging&&  image&&  isZoomedBigger) {
        image.style.cursor=  "grabbing";
        const currentX=  imagePos.x;
        const currentY=  imagePos.y;
        const newPosX=  currentX+  event.clientX-  mouseX;
        const newPosY=  currentY+  event.clientY-  mouseY;
        image.style.transform=   `translate(${newPosX}px, ${newPosY}px)`;
       }
     },
    [
      imagePos.x,
      imagePos.y,
      imageRef,
      isDragging,
      isZoomedBigger,
      mouseX,
      mouseY]);


  const dragEndImpl=  useCallback(()=>  {
    setIsDragging(false);
    const image=  imageRef.current;
    if( image&&  isZoomedBigger&&  isDragging) {
      image.style.cursor=  "pointer";
      const rect=  image.getBoundingClientRect();
      const newPos=  { x: rect.left, y: rect.top};
      const currentX=  imagePos.x;
      const currentY=  imagePos.y;
      const newPosX=  currentX+  newPos.x-  dragBeforeX;
      const newPosY=  currentY+  newPos.y-  dragBeforeY;
      setImagePos({ x: newPosX, y: newPosY});
     }
   },[
    dragBeforeX,
    dragBeforeY,
    imagePos.x,
    imagePos.y,
    imageRef,
    isDragging,
    isZoomedBigger]);

  const handleDragEnd=  useCallback(
    (event)=>  {
      event.preventDefault();
      dragEndImpl();
     },
    [dragEndImpl]);

  const handleMouseUp=  useCallback(()=>  {
    if( isDragging) {
      dragEndImpl();
     }
   },[isDragging, dragEndImpl]);
  const checkZoomSize=  useCallback(()=>  {
    const { current: zoomArea}=   zoomRef;
    if( zoomArea) {
      const image=  zoomArea.querySelector("img");
      if( image) {
        const zoomedWidth=  image.naturalWidth*  currentScale;
        const zoomedHeight=  image.naturalHeight*  currentScale;
        const containerWidth=  window.innerWidth;
        const containerHeight=  window.innerHeight;
        setIsZoomedBigger(
          zoomedWidth>  containerWidth||  zoomedHeight>  containerHeight);

       }
     }
   },[currentScale, zoomRef]);
  const zoomIn=  useCallback(()=>  {
    const image=  imageRef.current;
    if( image&&  currentScale<  2) {
      const newScale=  currentScale+  0.1;
      setCurrentScale(newScale);
      image.style.width=   `${image.naturalWidth* newScale }px`;
      image.style.height=   `${image.naturalHeight* newScale }px`;
     }
   },[imageRef, currentScale]);
  const zoomOut=  useCallback(()=>  {
    const image=  imageRef.current;
    if( image&&  currentScale>  0.2) {
      const newScale=  currentScale-  0.1;
      setCurrentScale(newScale);
      image.style.width=   `${image.naturalWidth* newScale }px`;
      image.style.height=   `${image.naturalHeight* newScale }px`;
      const zoomedWidth=  image.naturalWidth*  newScale;
      const zoomedHeight=  image.naturalHeight*  newScale;
      const containerWidth=  window.innerWidth;
      const containerHeight=  window.innerHeight;
      if( zoomedWidth>  containerWidth||  zoomedHeight>  containerHeight) {
        image.style.transform=   `translate(0px, 0px)`;
        setImagePos({ x: 0, y: 0});
       }
     }
   },[imageRef, currentScale]);
  const resetZoom=  useCallback(()=>  {
    const image=  imageRef.current;
    if( image) {
      const viewportWidth=  window.innerWidth;
      const viewportHeight=  window.innerHeight;
      const margin=  0.2;
      const availableWidth=  viewportWidth*(  1-  margin);
      const availableHeight=  viewportHeight*(  1-  margin);
      const widthRatio=  availableWidth/  image.naturalWidth;
      const heightRatio=  availableHeight/  image.naturalHeight;
      const newScale=  Math.min(widthRatio, heightRatio);
      setCurrentScale(newScale);
      image.style.width=   `${image.naturalWidth* newScale }px`;
      image.style.height=   `${image.naturalHeight* newScale }px`;
      image.style.transform=  "translate(0px, 0px)";
      setImagePos({ x: 0, y: 0});
      checkZoomSize();
     }
   },[imageRef, checkZoomSize]);
  const resetScale=  useCallback(()=>  {
    const image=  imageRef.current;
    if( image) {
      setCurrentScale(1);
      image.style.width=   `${image.naturalWidth}px`;
      image.style.height=   `${image.naturalHeight}px`;
      image.style.transform=  "translate(0px, 0px)";
      setImagePos({ x: 0, y: 0});
     }
   },[imageRef]);
  useEffect(()=>  {
    const handleScroll=  (event)=>  {
      const { deltaY}=   event;
      if( deltaY>  0) {
        zoomOut();
       }else if( deltaY<  0) {
        zoomIn();
       }
     };
    const handleResize=  ()=>  {
      checkZoomSize();
     };
    checkZoomSize();
    window.addEventListener("wheel", handleScroll, { passive: false});
    window.addEventListener("resize", handleResize);
    window.addEventListener("mouseup", handleMouseUp);
    return ()=>  {
      window.removeEventListener("wheel", handleScroll);
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("mouseup", handleMouseUp);
     };
   },[zoomIn, zoomOut, checkZoomSize, handleMouseUp]);
  return {
    zoomIn,
    zoomOut,
    resetZoom,
    resetScale,
    isZoomedBigger,
    currentScale,
    handleDragStart,
    handleDrag,
    handleDragEnd};

 };

const index_css_ts_vanilla=  '';

var buttonStyle=  "hegajpe";
var captionStyle=  "hegajph";
var groupStyle=  "hegajpd";
var imageBottomContainerStyle=  "hegajpg";
var imagePreviewActionBarStyle=  "hegajpc";
var imagePreviewBackgroundStyle=  "hegajp2";
var imagePreviewModalCaptionStyle=  "hegajpb";
var imagePreviewModalCenterStyle=  "hegajpa";
var imagePreviewModalCloseButtonStyle=  "hegajp6";
var imagePreviewModalContainerStyle=  "hegajp9";
var imagePreviewModalStyle=  "hegajp3";
var loaded=  "hegajp4";
var scaleIndicatorButtonStyle=  "hegajpf";
var unloaded=  "hegajp5";

const previewBlockIdAtom=  atom(null);
const hasAnimationPlayedAtom=  atom(true);
previewBlockIdAtom.onMount=  (set)=>  {
  const callback=  (event)=>  {
    const target=  event.target;
    if( target?.tagName===  "IMG") {
      const imageBlock=  target.closest("affine-image");
      if( imageBlock) {
        const blockId=  imageBlock.getAttribute("data-block-id");
        if( !blockId)
          return;
        set(blockId);
       }
     }
   };
  window.addEventListener("dblclick", callback);
  return ()=>  {
    window.removeEventListener("dblclick", callback);
   };
 };

const toast=  (message, options)=>  {
  const mainContainer=  document.querySelector(
    '[plugin-id="@affine/image-preview-plugin"]');

  return toast$1(message, {
    portal: mainContainer||  document.body,
    ...options});

 };

const ImagePreviewModalImpl=  (props)=>  {
  const [blockId, setBlockId]=  useAtom(previewBlockIdAtom);
  const zoomRef=  useRef(null);
  const imageRef=  useRef(null);
  const {
    isZoomedBigger,
    handleDrag,
    handleDragStart,
    handleDragEnd,
    resetZoom,
    zoomIn,
    zoomOut,
    resetScale,
    currentScale}=
      useZoomControls({ zoomRef, imageRef});
  const [isOpen, setIsOpen]=  useAtom(hasAnimationPlayedAtom);
  const [hasPlayedAnimation, setHasPlayedAnimation]=  useState(false);
  useEffect(()=>  {
    let timeoutId;
    if( !isOpen) {
      timeoutId=  window.setTimeout(()=>  {
        props.onClose();
        setIsOpen(true);
       },300);
      return ()=>  {
        clearTimeout(timeoutId);
       };
     }
    return ()=>  {
     };
   },[isOpen, props, setIsOpen]);
  const nextImageHandler=  useCallback(
    (blockId2)=>  {
      assertExists(blockId2);
      const workspace=  props.workspace;
      if( !hasPlayedAnimation) {
        setHasPlayedAnimation(true);
       }
      const page=  workspace.getPage(props.pageId);
      assertExists(page);
      const block=  page.getBlockById(blockId2);
      assertExists(block);
      const nextBlock=  page.getNextSiblings(block).find(
        (block2)=>  block2.flavour===  "affine:image");

      if( nextBlock) {
        setBlockId(nextBlock.id);
       }
     },
    [props.pageId, props.workspace, setBlockId, hasPlayedAnimation]);

  const previousImageHandler=  useCallback(
    (blockId2)=>  {
      assertExists(blockId2);
      const workspace=  props.workspace;
      const page=  workspace.getPage(props.pageId);
      assertExists(page);
      const block=  page.getBlockById(blockId2);
      assertExists(block);
      const prevBlock=  page.getPreviousSiblings(block).findLast(
        (block2)=>  block2.flavour===  "affine:image");

      if( prevBlock) {
        setBlockId(prevBlock.id);
       }
      resetZoom();
     },
    [props.pageId, props.workspace, setBlockId, resetZoom]);

  const deleteHandler=  useCallback(
    (blockId2)=>  {
      const { pageId, workspace, onClose}=   props;
      const page=  workspace.getPage(pageId);
      assertExists(page);
      const block=  page.getBlockById(blockId2);
      assertExists(block);
      if( page.getPreviousSiblings(block).findLast(
        (block2)=>  block2.flavour===  "affine:image"))
         {
        const prevBlock=  page.getPreviousSiblings(block).findLast(
          (block2)=>  block2.flavour===  "affine:image");

        if( prevBlock) {
          setBlockId(prevBlock.id);
         }
       }else if( page.getNextSiblings(block).find(
        (block2)=>  block2.flavour===  "affine:image"))
         {
        const nextBlock=  page.getNextSiblings(block).find(
          (block2)=>  block2.flavour===  "affine:image");

        if( nextBlock) {
          setBlockId(nextBlock.id);
         }
       }else {
        onClose();
       }
      page.deleteBlock(block);
     },
    [props, setBlockId]);

  const downloadHandler=  useCallback(
    async( blockId2)=>  {
      const workspace=  props.workspace;
      const page=  workspace.getPage(props.pageId);
      assertExists(page);
      if( typeof blockId2===  "string") {
        const block=  page.getBlockById(blockId2);
        assertExists(block);
        const store=  await block.page.blobs;
        const url2=  store?.get(block.sourceId);
        const img=  await url2;
        if( !img) {
          return;
         }
        const arrayBuffer=  await img.arrayBuffer();
        const buffer=  new Uint8Array(arrayBuffer);
        let fileType;
        if( buffer[0]===  71&&  buffer[1]===  73&&  buffer[2]===  70&&  buffer[3]===  56) {
          fileType=  "image/gif";
         }else if( buffer[0]===  137&&  buffer[1]===  80&&  buffer[2]===  78&&  buffer[3]===  71) {
          fileType=  "image/png";
         }else if( buffer[0]===  255&&  buffer[1]===  216&&  buffer[2]===  255&&  buffer[3]===  224) {
          fileType=  "image/jpeg";
         }else {
          console.error("unknown image type");
          fileType=  "image/png";
         }
        const downloadUrl=  URL.createObjectURL(
          new Blob([arrayBuffer], { type: fileType}));

        const a=  document.createElement("a");
        a.href=  downloadUrl;
        a.download=  block.id??  "image";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
       }
     },
    [props.pageId, props.workspace]);

  const [caption, setCaption]=  useState(()=>  {
    const page=  props.workspace.getPage(props.pageId);
    assertExists(page);
    const block=  page.getBlockById(props.blockId);
    assertExists(block);
    return block?.caption;
   });
  useEffect(()=>  {
    const page=  props.workspace.getPage(props.pageId);
    assertExists(page);
    const block=  page.getBlockById(props.blockId);
    assertExists(block);
    setCaption(block?.caption);
   },[props.blockId, props.pageId, props.workspace]);
  const { data, error}=   useSWR(
    ["workspace", "image", props.pageId, props.blockId],
    {
      fetcher: ([_, __, pageId, blockId2])=>  {
        const page=  props.workspace.getPage(pageId);
        assertExists(page);
        const block=  page.getBlockById(blockId2);
        assertExists(block);
        return props.workspace.blobs.get(block?.sourceId);
       },
      suspense: true});


  o(error);
  const [prevData, setPrevData]=  useState(()=>  data);
  const [url, setUrl]=  useState(null);
  if( data===  null) {
    return null;
   }else if( prevData!==  data) {
    if( url) {
      URL.revokeObjectURL(url);
     }
    setUrl(URL.createObjectURL(data));
    setPrevData(data);
   }else if( !url) {
    setUrl(URL.createObjectURL(data));
   }
  if( !url) {
    return null;
   }
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: imagePreviewModalStyle,
      onClick: (event)=>  {
        if( event.target===  event.currentTarget) {
          setIsOpen(false);
         }
       },
      children: [
        /* @__PURE__ */ jsx("div", { className: imagePreviewModalContainerStyle, children: /* @__PURE__ */ jsx(
          "div",
          {
            className: clsx("zoom-area", { "zoomed-bigger": isZoomedBigger}),
            ref: zoomRef,
            children: /* @__PURE__ */ jsxs("div", { className: imagePreviewModalCenterStyle, children: [
              /* @__PURE__ */ jsx(
                "img",
                {
                  "data-blob-id": props.blockId,
                  "data-testid": "image-content",
                  src: url,
                  alt: caption,
                  ref: imageRef,
                  draggable: isZoomedBigger,
                  onMouseDown: handleDragStart,
                  onMouseMove: handleDrag,
                  onMouseUp: handleDragEnd,
                  onLoad: resetZoom}),


              isZoomedBigger?  null:  /* @__PURE__ */ jsx(
                "p",
                {
                  "data-testid": "image-caption-zoomedout",
                  className: imagePreviewModalCaptionStyle,
                  children: caption})]})})}),





        /* @__PURE__ */ jsxs(
          "div",
          {
            className: imageBottomContainerStyle,
            onClick: (event)=>  event.stopPropagation(),
            children: [
              isZoomedBigger&&  caption!==  ""?  /* @__PURE__ */ jsx("p", { "data-testid": "image-caption-zoomedin", className: captionStyle, children: caption}):   null,
              /* @__PURE__ */ jsxs("div", { className: imagePreviewActionBarStyle, children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(Tooltip, { content: "Previous", placement: "top", showArrow: true, children: /* @__PURE__ */ jsx(
                    IconButton,
                    {
                      "data-testid": "previous-image-button",
                      icon: /* @__PURE__ */ jsx(ArrowLeftSmallIcon, {}),
                      type: "plain",
                      className: buttonStyle,
                      onClick: ()=>  {
                        assertExists(blockId);
                        previousImageHandler(blockId);
                       }})}),


                  /* @__PURE__ */ jsx(Tooltip, { content: "Next", placement: "top", showArrow: true, children: /* @__PURE__ */ jsx(
                    IconButton,
                    {
                      "data-testid": "next-image-button",
                      icon: /* @__PURE__ */ jsx(ArrowRightSmallIcon, {}),
                      className: buttonStyle,
                      type: "plain",
                      onClick: ()=>  {
                        assertExists(blockId);
                        nextImageHandler(blockId);
                       }})})]}),



                /* @__PURE__ */ jsx("div", { className: groupStyle}),
                /* @__PURE__ */ jsx(Tooltip, { content: "Fit to Screen", placement: "top", showArrow: true, children: /* @__PURE__ */ jsx(
                  IconButton,
                  {
                    "data-testid": "fit-to-screen-button",
                    icon: /* @__PURE__ */ jsx(ViewBarIcon, {}),
                    type: "plain",
                    className: buttonStyle,
                    onClick: ()=>  resetZoom()})}),


                /* @__PURE__ */ jsx(Tooltip, { content: "Zoom out", placement: "top", showArrow: true, children: /* @__PURE__ */ jsx(
                  IconButton,
                  {
                    "data-testid": "zoom-out-button",
                    icon: /* @__PURE__ */ jsx(MinusIcon, {}),
                    className: buttonStyle,
                    type: "plain",
                    onClick: zoomOut})}),


                /* @__PURE__ */ jsx(Tooltip, { content: "Reset Scale", placement: "top", showArrow: true, children: /* @__PURE__ */ jsx(
                  Button,
                  {
                    "data-testid": "reset-scale-button",
                    type: "plain",
                    size: "large",
                    className: scaleIndicatorButtonStyle,
                    onClick: resetScale,
                    children:  `${(currentScale* 100).toFixed(0) }%`})}),


                /* @__PURE__ */ jsx(Tooltip, { content: "Zoom in", placement: "top", showArrow: true, children: /* @__PURE__ */ jsx(
                  IconButton,
                  {
                    "data-testid": "zoom-in-button",
                    icon: /* @__PURE__ */ jsx(PlusIcon, {}),
                    className: buttonStyle,
                    type: "plain",
                    onClick: ()=>  zoomIn()})}),


                /* @__PURE__ */ jsx("div", { className: groupStyle}),
                /* @__PURE__ */ jsx(Tooltip, { content: "Download", placement: "top", showArrow: true, children: /* @__PURE__ */ jsx(
                  IconButton,
                  {
                    "data-testid": "download-button",
                    icon: /* @__PURE__ */ jsx(DownloadIcon, {}),
                    type: "plain",
                    className: buttonStyle,
                    onClick: ()=>  {
                      assertExists(blockId);
                      downloadHandler(blockId).catch((err)=>  {
                        console.error("Could not download image", err);
                       });
                     }})}),


                /* @__PURE__ */ jsx(
                  Tooltip,
                  {
                    content: "Copy to clipboard",
                    placement: "top",
                    showArrow: true,
                    children: /* @__PURE__ */ jsx(
                      IconButton,
                      {
                        "data-testid": "copy-to-clipboard-button",
                        icon: /* @__PURE__ */ jsx(CopyIcon, {}),
                        type: "plain",
                        className: buttonStyle,
                        onClick: ()=>  {
                          if( !imageRef.current) {
                            return;
                           }
                          const canvas=  document.createElement("canvas");
                          canvas.width=  imageRef.current.naturalWidth;
                          canvas.height=  imageRef.current.naturalHeight;
                          const context=  canvas.getContext("2d");
                          if( !context) {
                            console.warn("Could not get canvas context");
                            return;
                           }
                          context.drawImage(imageRef.current, 0, 0);
                          canvas.toBlob((blob)=>  {
                            if( !blob) {
                              console.warn("Could not get blob");
                              return;
                             }
                            const dataUrl=  URL.createObjectURL(blob);
                            global.navigator.clipboard.write([new ClipboardItem({ "image/png": blob})]). then(()=>  {
                              console.log("Image copied to clipboard");
                              URL.revokeObjectURL(dataUrl);
                             }).catch((error2)=> {
                              console.error("Error copying image to clipboard", error2);
                              URL.revokeObjectURL(dataUrl);
                             });
                           },"image/png");
                          toast("Copied to clipboard.");
                         }})}),




                /* @__PURE__ */ jsx("div", { className: groupStyle}),
                /* @__PURE__ */ jsx(Tooltip, { content: "Delete", placement: "top", showArrow: true, children: /* @__PURE__ */ jsx(
                  IconButton,
                  {
                    "data-testid": "delete-button",
                    icon: /* @__PURE__ */ jsx(DeleteIcon, {}),
                    type: "plain",
                    className: buttonStyle,
                    onClick: ()=>  blockId&&  deleteHandler(blockId)})})]})]})]});









 };
const ErrorLogger=  (props)=>  {
  useEffect(()=>  {
    console.error("image preview modal error", props.error);
   },[props.error]);
  return null;
 };
const ImagePreviewErrorBoundary=  (props)=>  {
  return /* @__PURE__ */ jsx(ErrorBoundary, { fallbackRender: ErrorLogger, children: props.children});
 };
const ImagePreviewModal=  (props)=>  {
  const [blockId, setBlockId]=  useAtom(previewBlockIdAtom);
  const [isOpen, setIsOpen]=  useAtom(hasAnimationPlayedAtom);
  const handleKeyUp=  useCallback(
    (event)=>  {
      if( event.key===  "Escape") {
        event.preventDefault();
        event.stopPropagation();
        if( isOpen) {
          setIsOpen(false);
         }
        return;
       }
      if( !blockId) {
        return;
       }
      const workspace=  props.workspace;
      const page=  workspace.getPage(props.pageId);
      assertExists(page);
      const block=  page.getBlockById(blockId);
      assertExists(block);
      if( event.key===  "ArrowLeft") {
        const prevBlock=  page.getPreviousSiblings(block).findLast(
          (block2)=>  block2.flavour===  "affine:image");

        if( prevBlock) {
          setBlockId(prevBlock.id);
         }
       }else if( event.key===  "ArrowRight") {
        const nextBlock=  page.getNextSiblings(block).find(
          (block2)=>  block2.flavour===  "affine:image");

        if( nextBlock) {
          setBlockId(nextBlock.id);
         }
       }else {
        return;
       }
      event.preventDefault();
      event.stopPropagation();
     },
    [blockId, setBlockId, props.workspace, props.pageId, isOpen, setIsOpen]);

  useEffect(()=>  {
    document.addEventListener("keyup", handleKeyUp);
    return ()=>  {
      document.removeEventListener("keyup", handleKeyUp);
     };
   },[handleKeyUp]);
  if( !blockId) {
    return null;
   }
  return /* @__PURE__ */ jsx(ImagePreviewErrorBoundary, { children: /* @__PURE__ */ jsxs(
    "div",
    {
      "data-testid": "image-preview-modal",
      className:  `${imagePreviewBackgroundStyle} ${isOpen? loaded:  unloaded }`,
      children: [
        /* @__PURE__ */ jsx(Suspense, { children: /* @__PURE__ */ jsx(
          ImagePreviewModalImpl,
          {
            ...props,
            blockId,
            onClose: ()=>  setBlockId(null)})}),


        /* @__PURE__ */ jsx(
          "button",
          {
            "data-testid": "image-preview-close-button",
            onClick: ()=>  {
              setBlockId(null);
             },
            className: imagePreviewModalCloseButtonStyle,
            children: /* @__PURE__ */ jsx(
              "svg",
              {
                width: "10",
                height: "10",
                viewBox: "0 0 10 10",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: /* @__PURE__ */ jsx(
                  "path",
                  {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M0.286086 0.285964C0.530163 0.0418858 0.925891 0.0418858 1.16997 0.285964L5.00013 4.11613L8.83029 0.285964C9.07437 0.0418858 9.4701 0.0418858 9.71418 0.285964C9.95825 0.530041 9.95825 0.925769 9.71418 1.16985L5.88401 5.00001L9.71418 8.83017C9.95825 9.07425 9.95825 9.46998 9.71418 9.71405C9.4701 9.95813 9.07437 9.95813 8.83029 9.71405L5.00013 5.88389L1.16997 9.71405C0.925891 9.95813 0.530163 9.95813 0.286086 9.71405C0.0420079 9.46998 0.0420079 9.07425 0.286086 8.83017L4.11625 5.00001L0.286086 1.16985C0.0420079 0.925769 0.0420079 0.530041 0.286086 0.285964Z",
                    fill: "#77757D"})})})]})});









 };

const App=  ({ page})=>   {
  return /* @__PURE__ */ jsx(ImagePreviewModal, { pageId: page.id, workspace: page.workspace});
 };

const entry=  (context)=>  {
  context.register("editor", (div, editor)=>  {
    const root=  createRoot(div);
    root.render(createElement(App, { page: editor.page}));
    return ()=>  {
      root.unmount();
     };
   });
  return ()=>  {
   };
 };$h‍_once.entry(entry);
})
//# sourceURL=index.js
