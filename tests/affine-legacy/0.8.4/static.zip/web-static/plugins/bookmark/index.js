(({   imports: $h‍_imports,   liveVar: $h‍_live,   onceVar: $h‍_once,   importMeta: $h‍____meta,  }) => {   let StrictMode,useState,useMemo,useCallback,useEffect,createElement,createRoot,jsx,MuiClickAwayListener,PureMenu,MenuItem;$h‍_imports([["react", [["StrictMode", [$h‍_a => (StrictMode = $h‍_a)]],["useState", [$h‍_a => (useState = $h‍_a)]],["useMemo", [$h‍_a => (useMemo = $h‍_a)]],["useCallback", [$h‍_a => (useCallback = $h‍_a)]],["useEffect", [$h‍_a => (useEffect = $h‍_a)]],["createElement", [$h‍_a => (createElement = $h‍_a)]]]],["react-dom/client", [["createRoot", [$h‍_a => (createRoot = $h‍_a)]]]],["react/jsx-runtime", [["jsx", [$h‍_a => (jsx = $h‍_a)]]]],["@affine/component", [["MuiClickAwayListener", [$h‍_a => (MuiClickAwayListener = $h‍_a)]],["PureMenu", [$h‍_a => (PureMenu = $h‍_a)]],["MenuItem", [$h‍_a => (MenuItem = $h‍_a)]]]]]);   




const menuOptions=  [
  {
    id: "dismiss",
    label: "Dismiss"},

  {
    id: "bookmark",
    label: "Create bookmark"}];


function getCurrentNativeRange(selection=  window.getSelection()) {
  if( !selection) {
    return null;
   }
  if( selection.rangeCount===  0) {
    return null;
   }
  if( selection.rangeCount>  1) {
    console.warn("getCurrentRange may be wrong, rangeCount > 1");
   }
  return selection.getRangeAt(0);
 }
const handleEnter=  ({
  page,
  selectedOption,
  callback})=>
      {
  if( selectedOption===  "dismiss") {
    return callback();
   }
  const native=  getCurrentNativeRange();
  if( !native) {
    return callback();
   }
  const container=  native.startContainer;
  const element=  container instanceof Element?  container:  container?.parentElement;
  const virgo=  element?.closest(
    "[data-virgo-root]")?.
     virgoEditor;
  if( !virgo) {
    return callback();
   }
  const linkInfo=  virgo?.getDeltasByVRange({
    index: native.startOffset,
    length: 0}).
     find((delta)=>  delta[0]?.attributes?.link);
  if( !linkInfo) {
    return;
   }
  const [, { index, length}]=   linkInfo;
  const link=  linkInfo[0]?.attributes?.link;
  const model=  element?.closest(
    "[data-block-id]")?.
     model;
  if( !model) {
    return callback();
   }
  const parent=  page.getParent(model);
  if( !parent) {
    return callback();
   }
  const currentBlockIndex=  parent.children.indexOf(model);
  page.addBlock(
    "affine:bookmark",
    { url: link},
    parent,
    currentBlockIndex+  1);

  virgo?.deleteText({
    index,
    length});

  if( model.isEmpty()) {
    page.deleteBlock(model);
   }
  return callback();
 };
const shouldShowBookmarkMenu=  (pastedBlocks)=>  {
  if( !pastedBlocks.length||  pastedBlocks.length>  1) {
    return;
   }
  const [firstBlock]=  pastedBlocks;
  if( !firstBlock.text||  !firstBlock.text.length||  firstBlock.text.length>  1) {
    return;
   }
  return !!firstBlock.text[0].attributes?.link;
 };
const BookMarkUI=  ({ page})=>   {
  const [anchor, setAnchor]=  useState(null);
  const [selectedOption, setSelectedOption]=  useState(
    menuOptions[0].id);

  const shortcutMap=  useMemo(
    ()=>(  {
      ArrowUp: ()=>  {
        const curIndex=  menuOptions.findIndex(
          ({ id})=>   id===  selectedOption);

        if( menuOptions[curIndex-  1]) {
          setSelectedOption(menuOptions[curIndex-  1].id);
         }else if( curIndex===  -1) {
          setSelectedOption(menuOptions[0].id);
         }else {
          setSelectedOption(menuOptions[menuOptions.length-  1].id);
         }
       },
      ArrowDown: ()=>  {
        const curIndex=  menuOptions.findIndex(
          ({ id})=>   id===  selectedOption);

        if( curIndex!==  -1&&  menuOptions[curIndex+  1]) {
          setSelectedOption(menuOptions[curIndex+  1].id);
         }else {
          setSelectedOption(menuOptions[0].id);
         }
       },
      Enter: ()=>  handleEnter({
        page,
        selectedOption,
        callback: ()=>  {
          setAnchor(null);
         }}),

      Escape: ()=>  {
        setAnchor(null);
       }}),

    [page, selectedOption]);

  const onKeydown=  useCallback(
    (e)=>  {
      const shortcut=  shortcutMap[e.key];
      if( shortcut) {
        e.stopPropagation();
        e.preventDefault();
        shortcut(e, page);
       }else {
        setAnchor(null);
       }
     },
    [page, shortcutMap]);

  useEffect(()=>  {
    const disposer=  page.slots.pasted.on((pastedBlocks)=>  {
      if( !shouldShowBookmarkMenu(pastedBlocks)) {
        return;
       }
      window.setTimeout(()=>  {
        setAnchor(getCurrentNativeRange());
       },100);
     });
    return ()=>  {
      disposer.dispose();
     };
   },[onKeydown, page, shortcutMap]);
  useEffect(()=>  {
    if( anchor) {
      document.addEventListener("keydown", onKeydown, { capture: true});
     }else {
      setSelectedOption(menuOptions[0].id);
      document.removeEventListener("keydown", onKeydown, { capture: true});
     }
    return ()=>  {
      document.removeEventListener("keydown", onKeydown, { capture: true});
     };
   },[anchor, onKeydown]);
  return anchor?  /* @__PURE__ */ jsx(
    MuiClickAwayListener,
    {
      onClickAway: ()=>  {
        setAnchor(null);
        setSelectedOption("");
       },
      children: /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(PureMenu, { open: !!anchor, anchorEl: anchor, placement: "bottom-start", children: menuOptions.map(({ id, label})=>   {
        return /* @__PURE__ */ jsx(
          MenuItem,
          {
            active: selectedOption===  id,
            onClick: ()=>  {
              handleEnter({
                page,
                selectedOption: id,
                callback: ()=>  {
                  setAnchor(null);
                 }});

             },
            disableHover: true,
            onMouseEnter: ()=>  {
              setSelectedOption(id);
             },
            children: label},

          id);

       })})})}):

      null;
 };
const App=  (props)=>  {
  return /* @__PURE__ */ jsx(StrictMode, { children: /* @__PURE__ */ jsx(BookMarkUI, { page: props.page})});
 };

const entry=  (context)=>  {
  console.log("register");
  context.register("editor", (div, editor)=>  {
    const root=  createRoot(div);
    root.render(createElement(App, { page: editor.page}));
    return ()=>  {
      root.unmount();
     };
   });
  return ()=>  {
    console.log("unregister");
   };
 };$h‍_once.entry(entry);
})
//# sourceURL=index.js
