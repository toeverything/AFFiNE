(({   imports: $h‍_imports,   liveVar: $h‍_live,   onceVar: $h‍_once,   importMeta: $h‍____meta,  }) => {   let lazy,createElement,createRoot;$h‍_imports([["react", [["lazy", [$h‍_a => (lazy = $h‍_a)]],["createElement", [$h‍_a => (createElement = $h‍_a)]]]],["react-dom/client", [["createRoot", [$h‍_a => (createRoot = $h‍_a)]]]]]);   


const HeaderItem=  lazy(
  ()=>  $h‍_import('./app-21e368.mjs').then(({HeaderItem:HeaderItem2})=>( { default: HeaderItem2})));

const entry=  (context)=>  {
  console.log("register");
  console.log("hello, world!");
  context.register("headerItem", (div)=>  {
    const root=  createRoot(div);
    root.render(createElement(HeaderItem));
    return ()=>  {
      root.unmount();
     };
   });
  context.register("formatBar", (div)=>  {
    const root=  createRoot(div);
    root.render(createElement(HeaderItem));
    return ()=>  {
      root.unmount();
     };
   });
  return ()=>  {
    console.log("unregister");
   };
 };$h‍_once.entry(entry);
})
//# sourceURL=index.js
