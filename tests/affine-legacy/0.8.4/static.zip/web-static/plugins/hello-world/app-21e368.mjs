(({   imports: $h‍_imports,   liveVar: $h‍_live,   onceVar: $h‍_once,   importMeta: $h‍____meta,  }) => {   let jsx,Tooltip,Logo1Icon,IconButton,useCallback;$h‍_imports([["react/jsx-runtime", [["jsx", [$h‍_a => (jsx = $h‍_a)]]]],["@affine/component", [["Tooltip", [$h‍_a => (Tooltip = $h‍_a)]]]],["@blocksuite/icons", [["Logo1Icon", [$h‍_a => (Logo1Icon = $h‍_a)]]]],["@toeverything/components/button", [["IconButton", [$h‍_a => (IconButton = $h‍_a)]]]],["react", [["useCallback", [$h‍_a => (useCallback = $h‍_a)]]]]]);   





const HeaderItem=  ()=>  {
  return /* @__PURE__ */ jsx(Tooltip, { content: "Plugin Enabled", children: /* @__PURE__ */ jsx(
    IconButton,
    {
      onClick: useCallback(()=>  {
        console.log("clicked hello world!");
       },[]),
      children: /* @__PURE__ */ jsx(Logo1Icon, {})})});


 };$h‍_once.HeaderItem(HeaderItem);
})
//# sourceURL=app-21e368.mjs
