!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=Error().stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="a315f6f3-bfb8-4f98-8962-00e8bcf62fef",e._sentryDebugIdIdentifier="sentry-dbid-a315f6f3-bfb8-4f98-8962-00e8bcf62fef")}catch(e){}}();var _global="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};_global.SENTRY_RELEASE={id:"d7464b9fad4ebae54ec929bd63569e9674fc5dee"};"use strict";(globalThis.webpackChunk_affine_monorepo=globalThis.webpackChunk_affine_monorepo||[]).push([[5566],{90090:(e,n,t)=>{/**
 * @license React
 * use-sync-external-store-shim.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var f=t(70846),o="function"==typeof Object.is?Object.is:function(e,n){return e===n&&(0!==e||1/e==1/n)||e!=e&&n!=n},u=f.useState,i=f.useEffect,r=f.useLayoutEffect,a=f.useDebugValue;function d(e){var n=e.getSnapshot;e=e.value;try{var t=n();return!o(e,t)}catch(e){return!0}}var s="undefined"==typeof window||void 0===window.document||void 0===window.document.createElement?function(e,n){return n()}:function(e,n){var t=n(),f=u({inst:{value:t,getSnapshot:n}}),o=f[0].inst,s=f[1];return r(function(){o.value=t,o.getSnapshot=n,d(o)&&s({inst:o})},[e,t,n]),i(function(){return d(o)&&s({inst:o}),e(function(){d(o)&&s({inst:o})})},[e]),a(t),t};n.useSyncExternalStore=void 0!==f.useSyncExternalStore?f.useSyncExternalStore:s},88520:(e,n,t)=>{e.exports=t(90090)}}]);
//# sourceMappingURL=chunk.npm-async-use-sync-external-store.js.map