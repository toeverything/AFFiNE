!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},o=Error().stack;o&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[o]="8b5695df-42ea-44ec-9cac-bd40c459e394",e._sentryDebugIdIdentifier="sentry-dbid-8b5695df-42ea-44ec-9cac-bd40c459e394")}catch(e){}}();var _global="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};_global.SENTRY_RELEASE={id:"d7464b9fad4ebae54ec929bd63569e9674fc5dee"};"use strict";(globalThis.webpackChunk_affine_monorepo=globalThis.webpackChunk_affine_monorepo||[]).push([[9917],{20774:(e,o,r)=>{/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var n=r(70846),f=Symbol.for("react.element"),d=Symbol.for("react.fragment"),t=Object.prototype.hasOwnProperty,a=n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,l={key:!0,ref:!0,__self:!0,__source:!0};function s(e,o,r){var n,d={},s=null,i=null;for(n in void 0!==r&&(s=""+r),void 0!==o.key&&(s=""+o.key),void 0!==o.ref&&(i=o.ref),o)t.call(o,n)&&!l.hasOwnProperty(n)&&(d[n]=o[n]);if(e&&e.defaultProps)for(n in o=e.defaultProps)void 0===d[n]&&(d[n]=o[n]);return{$$typeof:f,type:e,key:s,ref:i,props:d,_owner:a.current}}o.Fragment=d,o.jsx=s,o.jsxs=s},2873:(e,o,r)=>{e.exports=r(20774)}}]);
//# sourceMappingURL=chunk.npm-async-react.js.map